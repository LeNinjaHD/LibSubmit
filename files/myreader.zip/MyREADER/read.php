<?php
$pdo = new PDO("mysql:host=localhost;dbname=dbreader", "root", "");
$sql = 'SELECT * FROM dbreader;';
echo "Einträge in der Datenbank: <p>";
foreach ($pdo->query($sql) as $row) {
  echo "Name des Eintrages: ".$row['name']."  -  Datum: ".$row['datum']."<br />";
  echo "Inhalt des Eintrages: <br>".$row['inhalt']."<p>";
}
 ?>
