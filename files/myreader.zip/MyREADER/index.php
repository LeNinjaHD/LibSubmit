<?php
echo "Wilkommen bei dem MyReader!<br>Du kannst <a href='read.php'>HIER</a> Deine Datenbank auslesen und <a href='insert.php'>HIER</a> Kannst du in deine Datenbank schreiben (BETA)";
?>
